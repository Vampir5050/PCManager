﻿// PCManager
#include"FileAndDirectory.h"

using namespace std;

int main()
{
	SetConsoleCP(1251);
	SetConsoleOutputCP(1251);
	string Way;
	string Name;
	int Decision;
	do
	{
		system("cls");
		cout << R"(Что выберете?
1 - Создать файл
2 - Создать директорию
3 - Поиск файла
4 - Переименовать файл/директорию
5 - Переместить файл/директорию
6 - Копировать файл/директорию
7 - Удаление файла/директории
8 - Вывод директории на экран
0 - Выход
)" << endl;
		cin >> Decision;
		FileAndDirectory object;
		switch (Decision)
		{
		//Создание файла
		case 1:
		{
			object.Set_Path();
			object.Create_File();
			system("pause");
		}
		break;
		//создание директории
		case 2:
		{
			object.Set_Path();
			object.Create_Directory();
			system("pause");
		}
		break;
		// поиск
		case 3:
		{
			object.Find();
			system("pause");
		}
		break;
		//переименование
		case 4:
		{
			object.Set_Path();
			object.Rename();
			system("pause");
		}
		break;
		//перемещение
		case 5:
		{
			object.Set_Path();
			object.Move();
			system("pause");
		}
		break;
		//копирование
		case 6:
		{
			object.Set_Path();
			object.Copy();
			system("pause");
		}
		break;
		//удаление
		case 7:
		{
			object.Set_Path();
			object.Remove();
			system("pause");
		}
		break;
		//вывод на экран
		case 8:
		{
			object.Set_Path();
			object.Show();
			system("pause");
		}
		break;
		default:
			break;
		}

	} while (Decision != 0);
	
	
}


